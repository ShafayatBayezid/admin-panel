# Assessment for 'Frontend Developer HTML CSS'

### `Live Demo`

Visit [https://shafayat.net/admin-panel/](https://shafayat.net/admin-panel/) to view it in your browser.
